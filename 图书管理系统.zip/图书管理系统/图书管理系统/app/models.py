"""
Definition of models.
"""
from django.core.urlresolvers import reverse
from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Book(models.Model):
    bookNumber = models.CharField(max_length = 8, default="")
    category = models.CharField(max_length = 10, default = "")
    title = models.CharField(max_length = 40, default = "")
    press = models.CharField(max_length = 30, default = "")
    year = models.PositiveSmallIntegerField(default = 0)  
    author = models.CharField(max_length = 20, default = "")
    price = models.CharField(max_length = 20, default = "")
    total = models.PositiveSmallIntegerField(default = 0)
    stock = models.PositiveSmallIntegerField(default = 0)


class Card(models.Model):
    user = models.OneToOneField(User, on_delete = models.CASCADE)
    department = models.CharField(max_length = 40, default = "")
    type = models.CharField(max_length = 30, default = "")

class Administrator(models.Model):
    user = models.OneToOneField(User, on_delete = models.CASCADE)
    phone = models.CharField(max_length = 30, default = "")
#卡号用username
#姓名用firstname
#密码用password  
class Borrow(models.Model):
    bookNumber = models.ForeignKey('Book', on_delete = models.CASCADE)
    user = models.ForeignKey('Card', on_delete=models.CASCADE)
    borrow_date = models.DateTimeField()
    return_date = models.DateTimeField()
    is_returned = models.CharField(max_length = 10, default = "")



     