from django.conf.urls import url,include
import django.contrib.auth.views
from . import views
from django.contrib import admin

admin.autodiscover()
urlpatterns = [
    url(r'^$',views.userlogin),
    url(r'^login/$', views.userlogin, name='login'),
     url(r'^card_homepage/$', views.card_homepage, name='card_homepage'), 
    url(r'^logout/$',views.userlogout, name = 'logout'),
    url(r'^book_query/$', views.book_query, name='book_query'),
    url(r'^admin_homepage/$',views.admin_homepage, name = 'admin_homepage'),
    url(r'^add_book', views.add_book, name='add_book'),
    url(r'^query_result/$',views.query_result, name = 'query_result'),
    url(r'^borrow_book', views.borrow_book, name='borrow_book'),
    url(r'^return_book', views.return_book, name='return_book'),
    url(r'^add_card', views.add_card, name='add_card'),
    url(r'^delete_card', views.delete_card, name='delete_card'),
    url(r'^upload_book', views.upload_book, name='upload_book'),
]