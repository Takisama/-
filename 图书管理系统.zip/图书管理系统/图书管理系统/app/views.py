"""
Definition of views.
"""
from django.utils import timezone
from django import forms
from django.shortcuts import render,redirect
from django.http import HttpRequest,HttpResponseRedirect,HttpResponse,StreamingHttpResponse
from django.template import RequestContext
from datetime import datetime,timedelta
from .models import Administrator,Book,Card,Borrow
from django.core.mail import send_mail
from random import Random
from django.contrib import messages
from django.forms.models import model_to_dict
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password
from django.utils.http import urlquote
import re


def userlogin(request):

    if request.method == 'POST':

            username = request.POST['username']
            password = request.POST['password']
            #对比输入的用户名和密码和数据库中是否一致
            user = authenticate(username=username, password=password)

            if user is not None:
                if user.is_active:
                    login(request, user)
                    response = HttpResponseRedirect('/card_homepage/')
                    response.set_cookie('cookie_username', username)
                    if(Administrator.objects.filter(user=user)):
                        response = HttpResponseRedirect('/admin_homepage')
                    return response
                else:
                    return render(request, 'login.html')
            else:

                 return HttpResponse("<script >alert('用户名密码错误');window.location.href='/login';</script>")



    else:
        if(request.user.is_authenticated()):
            if(Administrator.objects.filter(user=request.user)):
                return HttpResponseRedirect('/admin_homepage')
            else:
                return HttpResponseRedirect('/card_homepage/')
        return render(request, 'login.html')


def card_homepage(request):
    username = request.COOKIES.get('cookie_username', '')
    borrowed_book = []
    user_id = User.objects.filter(username = username)
    for u in user_id:
        card_id = u.id
    borrow_id = Card.objects.filter(user_id = card_id)
    for c in borrow_id:
        borrowed_id = c.id
    not_returnbook = Borrow.objects.filter(user_id = borrowed_id ,is_returned = 0)
    for b in not_returnbook:
        nr_boonNumber = b.bookNumber_id
        book_info = Book.objects.filter(id = nr_boonNumber)
        return_time = b.return_date-timedelta(hours = 8)
        for info in book_info:
            bookNumber = info.bookNumber
            category = info.category
            title = info.title
            press = info.press
            year = info.year
            author = info.author
            price = info.price
            borrowed_book.append({'bookNumber':bookNumber,'category':category,'title':title,'press':press,'year':year,'author':author,'price':price,'return_time':return_time})
            
    return render(request, 'card_homepage.html', {'username': username, 'borrowed_book':borrowed_book})

def userlogout(request):

    response = HttpResponseRedirect('/login/')
    response.delete_cookie('username')
#    response.delete_cookie('identity')
    logout(request)
    return response

def admin_homepage(request):
    username = request.COOKIES.get('cookie_username', '')
    return render(request, 'admin_homepage.html', {'username': username})

def upload_book(request):
    if request.method == 'POST':
        myFile = request.FILES.get("file",None)
        if myFile == None:
            return HttpResponse("<script>alert('请添加文件！');window.location.href='/admin_homepage';</script>")
        
        while True:
            lines = myFile.readline().decode(encoding = "gb2312").strip('\n').strip('\r')
            if not lines:
                break
                pass
            else:
                bookNumber,category,title,press,year,author,price,total,stock = lines.split(' ')
                existBook = Book.objects.filter(bookNumber = bookNumber)
                if existBook:
                    for s in existBook:
                        bookstock = s.stock
                        booktotal = s.total
                    bookstock = bookstock + int(total)
                    booktotal = booktotal + int(total)
                    Book.objects.filter(bookNumber = bookNumber).update(stock = bookstock,total = booktotal);
                    
                else:
                    Book.objects.create(bookNumber = bookNumber, category = category, title = title,press = press,year = year, author = author, price = price, total = total, stock =stock)
        return HttpResponse("<script>alert('提交成功！');window.location.href='/admin_homepage';</script>")


def add_book(request):
     if request.method =='POST':
        bookNumber = request.POST['bookNumber']
        category = request.POST['category']
        title = request.POST['title']
        press = request.POST['press']
        year = request.POST['year']
        author = request.POST['author']
        price = request.POST['price']
        Number = request.POST['Number']
        if bookNumber == "":
            return HttpResponse( "<script>alert('请填写书号！');window.location.href='/admin_homepage';</script>")
        if category == "":
            return HttpResponse( "<script>alert('请填写书籍类别！');window.location.href='/admin_homepage';</script>")
        if title == "":
            return HttpResponse( "<script>alert('请填写书名！');window.location.href='/admin_homepage';</script>")
        if press == "":
            return HttpResponse( "<script>alert('请填写出版社！');window.location.href='/admin_homepage';</script>")
        if year == "":
            return HttpResponse( "<script>alert('请填写年份！');window.location.href='/admin_homepage';</script>")
        if author == "":
            return HttpResponse( "<script>alert('请填写作者！');window.location.href='/admin_homepage';</script>")
        if price == "":
            return HttpResponse( "<script>alert('请填写价格！');window.location.href='/admin_homepage';</script>")
        if Number == "":
            return HttpResponse( "<script>alert('请填写入库书籍数量！');window.location.href='/admin_homepage';</script>")
        ExistBno = Book.objects.filter(bookNumber = bookNumber)
        if ExistBno:
                
                total = Book.objects.filter(bookNumber = bookNumber)
                for T in total:
                    booktotal = T.total

                stock  = Book.objects.filter(bookNumber = bookNumber)
                for S in stock:
                    bookstock = S.stock
                booktotal = booktotal+ int(Number)
                bookstock = bookstock + int(Number)
                Book.objects.filter(bookNumber = bookNumber).update(total = booktotal);
                Book.objects.filter(bookNumber = bookNumber).update(stock = bookstock);
                return HttpResponse("<script>alert('提交成功！该书已存在书库，对书本数量进行修改');window.location.href='/admin_homepage';</script>")   
        else :
       
            Book.objects.create(bookNumber = bookNumber, category = category, title = title,press = press,year = year, author = author, price = price, total = Number, stock = Number)
            return HttpResponse("<script>alert('提交成功！');window.location.href='/admin_homepage';</script>")     


   
                


    
def book_query(request):
    username = request.COOKIES.get('cookie_username', '')
    islogin=request.user.is_authenticated()
    return render(request,'book_query.html',{'username':username})


def query_result(request):
    if request.method =='POST':
        ret = []
        query_content = request.POST['content']   
        startyear = request.POST['startyear']
        endyear = request.POST['endyear']
        minprice = request.POST['minprice']
        maxprice = request.POST['maxprice']
        query = request.POST['query']
        if(query == 'BookNumber'):
            book = Book.objects.filter(bookNumber = query_content);
            for b in book:
                bookNumber = b.bookNumber
                category = b.category
                title = b.title
                press = b.press
                year = b.year
                if(startyear!='' and endyear ==''):
                    if(year >= int(startyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear !=''):
                    if(year <=int(endyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear==''):
                    x=1
                if(startyear!=''and endyear !=''):
                    if(int(startyear)>int(endyear)):
                           return HttpResponse( "<script>alert('开始年份请小于结束年份！');window.location.href='/book_query';</script>")  
                    if(year>=int(startyear) and year<=int(endyear)):
                            x=1
                    else:
                            x=0
                author = b.author
                price = b.price
                if(minprice!='' and maxprice==''):
                    if(float(price)>=float(minprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice!=''):
                    if(float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice==''):
                        y=1
                if(minprice!='' and maxprice!=''):
                    if(float(minprice)>float(maxprice)):
                           return HttpResponse( "<script>alert('最大价格请大于最小价格！');window.location.href='/book_query';</script>") 
                    if(float(price)>=float(minprice) and float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                total = b.total
                stock = b.stock
                if(x==1 and y==1):
                    ret.append({'bookNumber':bookNumber,'category':category,'title':title,'press':press,'year':year,'author':author,'price':price,'total':total,'stock':stock})
                
            return render(request,'query_result.html',{'ret':ret})
        if(query == 'category'):
            category = Book.objects.filter(category = query_content);
            for b in category:
                bookNumber = b.bookNumber
                category = b.category
                title = b.title
                press = b.press
                year = b.year
                if(startyear!='' and endyear ==''):
                    if(year >= int(startyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear !=''):
                    if(year <=int(endyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear==''):
                    x=1
                if(startyear!=''and endyear !=''):
                    if(int(startyear)>int(endyear)):
                           return HttpResponse( "<script>alert('开始年份请小于结束年份！');window.location.href='/book_query';</script>")  
                    if(year>=int(startyear) and year<=int(endyear)):
                            x=1
                    else:
                            x=0
                author = b.author
                price = b.price
                if(minprice!='' and maxprice==''):
                    if(float(price)>=float(minprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice!=''):
                    if(float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice==''):
                        y=1
                if(minprice!='' and maxprice!=''):
                    if(float(minprice)>float(maxprice)):
                           return HttpResponse( "<script>alert('最大价格请大于最小价格！');window.location.href='/book_query';</script>") 
                    if(float(price)>=float(minprice) and float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                total = b.total
                stock = b.stock
                
                if(x==1 and y==1):
                    ret.append({'bookNumber':bookNumber,'category':category,'title':title,'press':press,'year':year,'author':author,'price':price,'total':total,'stock':stock})
            return render(request,'query_result.html',{'ret':ret})
        if(query == 'title'):
            title = Book.objects.filter(title = query_content);
            for b in title:
                bookNumber = b.bookNumber
                category = b.category
                title = b.title
                press = b.press
                year = b.year
                if(startyear!='' and endyear ==''):
                    if(year >= int(startyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear !=''):
                    if(year <=int(endyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear==''):
                    x=1
                if(startyear!=''and endyear !=''):
                    if(int(startyear)>int(endyear)):
                           return HttpResponse( "<script>alert('开始年份请小于结束年份！');window.location.href='/book_query';</script>")  
                    if(year>=int(startyear) and year<=int(endyear)):
                            x=1
                    else:
                            x=0
                author = b.author
                price = b.price
                if(minprice!='' and maxprice==''):
                    if(float(price)>=float(minprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice!=''):
                    if(float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice==''):
                        y=1
                if(minprice!='' and maxprice!=''):
                    if(float(minprice)>float(maxprice)):
                           return HttpResponse( "<script>alert('最大价格请大于最小价格！');window.location.href='/book_query';</script>") 
                    if(float(price)>=float(minprice) and float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                total = b.total
                stock = b.stock
                if(x==1 and y==1):
                    ret.append({'bookNumber':bookNumber,'category':category,'title':title,'press':press,'year':year,'author':author,'price':price,'total':total,'stock':stock})
            return render(request,'query_result.html',{'ret':ret})
        if(query == 'author'):
            author = Book.objects.filter(author = query_content);
            for b in author:
                bookNumber = b.bookNumber
                category = b.category
                title = b.title
                press = b.press
                year = b.year
                if(startyear!='' and endyear ==''):
                    if(year >= int(startyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear !=''):
                    if(year <=int(endyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear==''):
                    x=1
                if(startyear!=''and endyear !=''):
                    if(int(startyear)>int(endyear)):
                           return HttpResponse( "<script>alert('开始年份请小于结束年份！');window.location.href='/book_query';</script>")  
                    if(year>=int(startyear) and year<=int(endyear)):
                            x=1
                    else:
                            x=0
                author = b.author
                price = b.price
                if(minprice!='' and maxprice==''):
                    if(float(price)>=float(minprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice!=''):
                    if(float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice==''):
                        y=1
                if(minprice!='' and maxprice!=''):
                    if(float(minprice)>float(maxprice)):
                           return HttpResponse( "<script>alert('最大价格请大于最小价格！');window.location.href='/book_query';</script>") 
                    if(float(price)>=float(minprice) and float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                total = b.total
                stock = b.stock
                if(x==1 and y==1):
                  ret.append({'bookNumber':bookNumber,'category':category,'title':title,'press':press,'year':year,'author':author,'price':price,'total':total,'stock':stock})
            return render(request,'query_result.html',{'ret':ret})
        if(query == 'press'):
            press = Book.objects.filter(press = query_content);
            for b in press:
                bookNumber = b.bookNumber
                category = b.category
                title = b.title
                press = b.press
                year = b.year
                if(startyear!='' and endyear ==''):
                    if(year >= int(startyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear !=''):
                    if(year <=int(endyear)):
                        x=1
                    else:
                        x=0
                if(startyear=='' and endyear==''):
                    x=1
                if(startyear!=''and endyear !=''):
                    if(int(startyear)>int(endyear)):
                           return HttpResponse( "<script>alert('开始年份请小于结束年份！');window.location.href='/book_query';</script>")  
                    if(year>=int(startyear) and year<=int(endyear)):
                            x=1
                    else:
                            x=0
                author = b.author
                price = b.price
                if(minprice!='' and maxprice==''):
                    if(float(price)>=float(minprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice!=''):
                    if(float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                if(minprice=='' and maxprice==''):
                        y=1
                if(minprice!='' and maxprice!=''):
                    if(float(minprice)>float(maxprice)):
                           return HttpResponse( "<script>alert('最大价格请大于最小价格！');window.location.href='/book_query';</script>") 
                    if(float(price)>=float(minprice) and float(price)<=float(maxprice)):
                        y=1
                    else:
                        y=0
                total = b.total
                stock = b.stock
                if(x==1 and y==1):
                    ret.append({'bookNumber':bookNumber,'category':category,'title':title,'press':press,'year':year,'author':author,'price':price,'total':total,'stock':stock})
            return render(request,'query_result.html',{'ret':ret})


def borrow_book(request):
    if request.method == 'POST':
        returnDate=[]
        bookNumber = request.POST['bNo']
        username = request.COOKIES.get('cookie_username', '')
        user_id = User.objects.filter(username = username)
        for u in user_id:
            card = u.id
        card_id = Card.objects.filter(user_id = card)
        for c in card_id:
            borrow_id = c.id
        book_stock = Book.objects.filter(bookNumber = bookNumber)
        if not book_stock:
            return HttpResponse("<script>alert('该书不存在');window.location.href='/card_homepage';</script>")
        for s in book_stock:
            stock = s.stock
            id = s.id
        if stock>0 :
            stock = stock - 1;
            
            borrow_time =  datetime.now()+timedelta(hours = 8)
            return_time = borrow_time + timedelta(days=30);
            b1 = Borrow(borrow_date = borrow_time, return_date = return_time,user_id = borrow_id ,bookNumber_id = id , is_returned = 0)
            b1.save()
            Book.objects.filter(bookNumber = bookNumber).update(stock = stock);
            return HttpResponse("<script>alert('借书成功');window.location.href='/card_homepage';</script>")
        else:
            return_time = Borrow.objects.filter(bookNumber_id =id, is_returned = 0).order_by("return_date")
            for r in return_time:
                return_date = r.return_date
                break
            returnDate.append({'return_date':return_date})
            return render(request, 'card_homepage.html', {'username': username, 'returnDate':returnDate})
        
    
def return_book(request):
    if   request.method =='POST':
             bookNumber = request.POST['bNo']
             username = request.COOKIES.get('cookie_username', '')
             user_id = User.objects.filter(username = username)
             for u in user_id:
               card = u.id
             card_id = Card.objects.filter(user_id = card)
             for c in card_id:
                borrow_id = c.id
             bookN = Book.objects.filter(bookNumber = bookNumber)
             for b in bookN:
                book_id = b.id
             ExistBorrow = Borrow.objects.filter(bookNumber_id = book_id,user_id=borrow_id, is_returned = 0)
             i = 0
             for e in ExistBorrow:
                i = i+1
             if not ExistBorrow:
                  return HttpResponse("<script>alert('未借阅该书');window.location.href='/card_homepage';</script>") 
             else:
                
                  book_stock = Book.objects.filter(bookNumber = bookNumber)
                  for s in book_stock:
                     stock = s.stock
                  while(i):
                    stock = stock + 1
                    i = i - 1
                  return_time =  datetime.now()+timedelta(hours = 8)
                  Book.objects.filter(bookNumber = bookNumber).update(stock = stock); 
                  Borrow.objects.filter(bookNumber_id =book_id,user_id=borrow_id,is_returned=0).update(is_returned = 1,return_date = return_time)
                  return HttpResponse("<script>alert('还书成功');window.location.href='/card_homepage';</script>") 
                
                
def add_card(request):
    if request.method =='POST':
        cardNumber = request.POST['cno']
        username = request.POST['name']
        cardtype = request.POST['ctp']
        department = request.POST['department']
        if cardNumber == "":
            return HttpResponse( "<script>alert('请填写卡号！');window.location.href='/admin_homepage';</script>")
        if username == "":
            return HttpResponse( "<script>alert('请填写用户名！');window.location.href='/admin_homepage';</script>")
        if cardtype == "":
            return HttpResponse( "<script>alert('请填写账户类别！');window.location.href='/admin_homepage';</script>")
        if department == "":
            return HttpResponse( "<script>alert('请填写单位！');window.location.href='/admin_homepage';</script>")
        userID = User.objects.filter(username = cardNumber)
        if not userID:
            return HttpResponse( "<script>alert('该学生用户不存在！');window.location.href='/admin_homepage';</script>")
        for u in userID:
            user_id = u.id
        existCard = Card.objects.filter(user_id = user_id)
        
        if existCard:
            return HttpResponse("<script>alert('该借书证已经存在！');window.location.href='/admin_homepage';</script>")
  
        else:
            c1 = Card(department = department, type =  cardtype, user_id = user_id)
            c1.save()
            User.objects.filter(username = cardNumber).update(first_name = username)
            return HttpResponse("<script>alert('添加借书证成功！');window.location.href='/admin_homepage';</script>")  


def delete_card(request):
    if request.method == 'POST':
        cardNumber = request.POST['cardNumber']
        cardN = User.objects.filter(username = cardNumber)
        for c in cardN:
            card_id = c.id
        existCard = Card.objects.filter(user_id = card_id)
        if existCard:
            Card.objects.filter(user_id = card_id).delete()
            return HttpResponse("<script>alert('删除借书证成功！');window.location.href='/admin_homepage';</script>")  
        else:
            return HttpResponse("<script>alert('该借书证不存在！');window.location.href='/admin_homepage';</script>")  