﻿"""
Package for 图书管理系统.
"""
